package application;
	
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Spinner;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.cell.MapValueFactory;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import java.io.*;
import java.util.*;
import javafx.util.Duration;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

	


public class Main extends Application {
	
	
	// global variables
	
	TableView captureTable;
	ScrollPane tableScrollBar;
	Text logText = new Text("");
	Text minCaptureSizeLabel;
	Text maxCaptureSizeLabel;
	Text packetCaptureTimeLabel;
	Text warningLabel;

	
	
	public void pythonScriptInit(CheckBox minCheckBox,Spinner minCaptureSize, Spinner minTimeSpinner) throws Exception {
	
		boolean isMinOptionSelected = minCheckBox.isSelected();
		int numPackets = (Integer) minCaptureSize.getValue();
		int captureTime = (Integer) minTimeSpinner.getValue();
		
		ProcessBuilder processBuilder;
		if (isMinOptionSelected == true) {
			processBuilder = new ProcessBuilder("python","packet-capture.py","True",Integer.toString(captureTime),Integer.toString(numPackets));
		}
		else {
			processBuilder = new ProcessBuilder("python","packet-capture.py","False",Integer.toString(captureTime));
		}

		processBuilder.redirectErrorStream(true);
		
		Map<String,String> env = processBuilder.environment();
		
		String workingDir = System.getProperty("user.dir");
		
		processBuilder.directory(new File(workingDir));
		
		Process process = processBuilder.start();
		
		InputStream out = process.getInputStream();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(out));
		
		String line;
		String contextFileName = "network_contexts/";
		int lineCount = 1;
		

	    while ((line = br.readLine()) != null) {
	    	
	    	if (lineCount != 2) {
		    	logText.setText(logText.getText() + line + "\n");
	    	}
	    	
	    	if (lineCount == 2) {
	    		contextFileName = contextFileName + line;
	    	}
	    	
	    	lineCount++;
	        
	    }
	    
	    ObservableList<Map<String, Object>> items = FXCollections.<Map<String, Object>>observableArrayList();

		System.out.println("file: "+contextFileName);
	    
	    try {
            // Open the file for reading
	    	FileReader contextFileReader = new FileReader(contextFileName);
            BufferedReader bufferedReader = new BufferedReader(contextFileReader);

            // Skip the first 7 lines - has irrelavent info for now
            for (int i = 0; i < 7; i++) {
                bufferedReader.readLine();
            }

            // Read the remaining lines
            List<String> remainingLines = new ArrayList<>();
            String contextLine;
            int flip = 0;
            while ((contextLine = bufferedReader.readLine()) != null) {
                remainingLines.add(contextLine);
            }

            // Close the BufferedReader
            bufferedReader.close();
            
            String ipAddress = "";
            String numOfPackets = "";

            items.clear();
            captureTable.getItems().clear();
            // Print the remaining lines
            for (int i = 0; i < remainingLines.size(); i=i+2) {
            	
            	
            	flip = 1;
            	ipAddress = remainingLines.get(i);
            	Map<String,Object> item = new HashMap<>();
                
            	System.out.println(ipAddress);

            	flip = 0;
            	numOfPackets = remainingLines.get(i+1);
            	System.out.println(remainingLines.get(i+1));
                // store CVE records in data structures
            	item.put("Source Address", ipAddress);
                item.put("Number of Packets",numOfPackets);
                System.out.println(item);
                items.add(item);
                    
            	
                
            }
            
            captureTable.getItems().addAll(items);
            
        } catch (IOException e) {
            e.printStackTrace();
        }

		
	}
	

	
	
	
	@Override
	public void start(Stage primaryStage) {
    	// update title
        primaryStage.setTitle("Network Traffic Analysis Tool");
        
        // Panes
        SplitPane root = new SplitPane();
        VBox panes = new VBox();
        HBox topPane = new HBox();
        
        // left pane + title setup
        VBox leftPane = new VBox();
        VBox leftPaneTitleBox = new VBox();
        Text leftPaneTitle = new Text("Capture Configuration");
        leftPaneTitle.setFont(Font.font("Verdana",FontWeight.BOLD,30));
        leftPane.setStyle("-fx-background-color: #7cc0d2;");
        leftPaneTitleBox.getChildren().add(leftPaneTitle);
        leftPaneTitleBox.setAlignment(Pos.CENTER);
        leftPane.getChildren().add(leftPaneTitleBox);
        leftPane.setSpacing(30);
        
        
        
        // middle pane + title setup
        VBox middlePane = new VBox();
        VBox middlePaneTitleBox = new VBox();
        Text middlePaneTitle = new Text("Packet Capture Results");
        middlePaneTitle.setFont(Font.font("Verdana",FontWeight.BOLD,30));
        middlePane.setStyle("-fx-background-color: #7cc0d2;");
        middlePaneTitleBox.getChildren().add(middlePaneTitle);
        middlePaneTitleBox.setAlignment(Pos.CENTER);
        middlePane.getChildren().add(middlePaneTitleBox);
        middlePane.setSpacing(30);
        
        
        
        // right pane + title setup
        VBox rightPane = new VBox();
        VBox rightPaneTitleBox = new VBox();
        Text rightPaneTitle = new Text("Log");
        rightPaneTitle.setFont(Font.font("Verdana",FontWeight.BOLD,30));
        rightPane.setStyle("-fx-background-color: #7cc0d2;");
        rightPaneTitleBox.getChildren().add(rightPaneTitle);
        rightPaneTitleBox.setAlignment(Pos.CENTER);
        rightPane.getChildren().add(rightPaneTitleBox);
        rightPane.setSpacing(30);
        
        topPane.getChildren().add(leftPane);
        topPane.getChildren().add(middlePane);
        topPane.getChildren().add(rightPane);
        
        // create fixed dividers for panes
        root.getItems().addAll(panes);
        //root.setDividerPositions(0.95,0.05);
        leftPane.maxWidthProperty().bind(topPane.widthProperty().multiply(0.33));
        leftPane.minWidthProperty().bind(topPane.widthProperty().multiply(0.33));
        middlePane.maxWidthProperty().bind(topPane.widthProperty().multiply(0.34));
        middlePane.minWidthProperty().bind(topPane.widthProperty().multiply(0.34));
        rightPane.maxWidthProperty().bind(topPane.widthProperty().multiply(0.33));
        rightPane.minWidthProperty().bind(topPane.widthProperty().multiply(0.33));
        
        topPane.minHeightProperty().bind(panes.heightProperty().multiply(1));
        topPane.maxHeightProperty().bind(panes.heightProperty().multiply(1));

        
        /*
         * This code is for the LEFT PANE
         * Objects include
         * -System Info text (+ container)
         * -Start Button(+ container)
         */
        
        // configure capture setup
        
        panes.getChildren().add(topPane);
        
        VBox systemInfoBox = new VBox();
        VBox warningBox = new VBox();
        HBox minCaptureSizeBox = new HBox();
        HBox packetCaptureTimeBox = new HBox();

        minCaptureSizeLabel = new Text("Minimum Capture Size:\t\t");
        Spinner minCaptureSpinner = new Spinner(1,1000,20);
        CheckBox minCheckBox = new CheckBox("");
        
        packetCaptureTimeLabel = new Text("Packet Capture Time:\t\t");
        Spinner packetCaptureTime = new Spinner(1,900,20);
        
        
        minCaptureSizeBox.getChildren().add(minCheckBox);
        minCaptureSizeBox.getChildren().add(minCaptureSizeLabel);
        minCaptureSizeBox.getChildren().add(minCaptureSpinner);
        
        
        VBox.setMargin(minCaptureSizeBox, new Insets(60, 0, 40, 20));
        
       

        
        packetCaptureTimeBox.getChildren().add(packetCaptureTimeLabel);
        packetCaptureTimeBox.getChildren().add(packetCaptureTime);

        VBox.setMargin(packetCaptureTimeBox, new Insets(0, 0, 40, 36));

        
        
        // append system info components to system info box; append warning to warning box
        systemInfoBox.getChildren().add(minCaptureSizeBox);
        systemInfoBox.getChildren().add(packetCaptureTimeBox);

        
        // create insets
        VBox.setMargin(systemInfoBox, new Insets(0, 0, 0, 0));
        
        // button setup
        Button btn = new Button();
        btn.setText("Begin Packet Capture");
        btn.setOnAction(new EventHandler<ActionEvent>() {
 
        	// action on button press
            @Override
            public void handle(ActionEvent event) {
            	
                logText.setText(logText.getText() + "Starting packet capture...\n");
                
                // get CVEs from CPEs
                logText.setText(logText.getText() + "Finished packet capture...\n");
                
                try {
					pythonScriptInit(minCheckBox,minCaptureSpinner,packetCaptureTime);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                

                

            }
        });
        VBox buttonBox = new VBox(btn);
        buttonBox.setAlignment(Pos.BASELINE_CENTER);
        VBox.setMargin(buttonBox, new Insets(200, 0, 0, 0));
        
        // append system info, start button, warning to left pane
        leftPane.getChildren().add(systemInfoBox);
        leftPane.getChildren().add(buttonBox);
        leftPane.getChildren().add(warningBox);
        
        
        /*
         * This code is for the MIDDLE PANE
         * The only object is a table w/ two columns (ID,description)
         */
        
        // init table; set properties
        captureTable = new TableView();
        
        captureTable.setEditable(true);
        captureTable.prefHeightProperty().bind(middlePane.heightProperty());
        captureTable.setStyle("-fx-background-color: #bddfe8;");
        
        // set CVE ID column, fix width
        TableColumn<Map,String> ipAddress = new TableColumn<>("Source Address");
        ipAddress.setCellValueFactory(new MapValueFactory<>("Source Address"));
        ipAddress.setResizable(false);
        ipAddress.setStyle("-fx-background-color: #a2d2df;");
        ipAddress.prefWidthProperty().bind(captureTable.widthProperty().multiply(0.5));
        
        // set CVE Description column, fix width
        TableColumn<Map,String> numOfPackets = new TableColumn<>("Number of Packets");
        numOfPackets.setCellValueFactory(new MapValueFactory<>("Number of Packets"));
        numOfPackets.setResizable(false);
        numOfPackets.setStyle("-fx-background-color: #a2d2df;");
        numOfPackets.prefWidthProperty().bind(captureTable.widthProperty().multiply(0.5));
        
        // add columns to table
        captureTable.getColumns().add(ipAddress);
        captureTable.getColumns().add(numOfPackets);
        
        // scroll bar for table
        ScrollPane tableScrollBar = new ScrollPane(captureTable);
        tableScrollBar.setFitToWidth(true);
        tableScrollBar.setContent(captureTable);
        tableScrollBar.setHbarPolicy(ScrollBarPolicy.NEVER);
        tableScrollBar.setVbarPolicy(ScrollBarPolicy.ALWAYS);
        captureTable.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY); 
        tableScrollBar.setFitToWidth(true);

        // add table to middle pane
        middlePane.getChildren().add(captureTable);
        middlePane.getChildren().add(tableScrollBar);
        
        
        /*
         * This code is for the RIGHT PANE
         * The only object is a text field
         */
        
        // setup log box; set properties
        logText.setStyle("-text-area-background:YELLOW;");
        VBox logTextBox = new VBox();
        logTextBox.getChildren().add(logText);
        logTextBox.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
        logTextBox.setStyle("-fx-background-color: #7cc0d2;");
        logTextBox.prefHeightProperty().bind(rightPane.heightProperty());

        // setup scrollbar; set properties
        ScrollPane logScrollBar = new ScrollPane(logTextBox);
        logScrollBar.setFitToWidth(true);
        logScrollBar.setContent(logTextBox);
        logScrollBar.setHbarPolicy(ScrollBarPolicy.NEVER);
        logScrollBar.setVbarPolicy(ScrollBarPolicy.ALWAYS);
        
        // append log box, scroll bar to right pane
        rightPane.getChildren().add(logTextBox);
        rightPane.getChildren().add(logScrollBar);
        
       
        
        


        
        
        // setup stage
        primaryStage.setScene(new Scene(root, 1200, 800));
        primaryStage.setResizable(false);
        primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	
	
	
	
	
	
}
