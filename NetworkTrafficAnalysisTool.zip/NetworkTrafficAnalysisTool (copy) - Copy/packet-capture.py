import pyshark
import re
from scapy.all import rdpcap
import datetime
from scapy.utils import RawPcapReader
import time
import sys

#
# Searches for source IP addresses where large volumes of packets came from
#
def detectDDOS(ipAddressDict,contextFileName):
    
    # get capture,control info
    avgPacketsPerMin,numOfPackets,captureTime = getContextValues(contextFileName)
    controlAvgPackets,totalNumOfPackets,totalTime = getControlValues()

    # look for surge of packets from a particular IP address
    suspiciousIPTraffic = False
    for ipAddressPackets in ipAddressDict.values():
        if (avgPacketsPerMin > 1.3*float(controlAvgPackets)) and (float(numOfPackets)*0.6 < ipAddressPackets) and (controlAvgPackets != 0):
            print("High network traffic from a particular IP address suggests a DDoS attack may be in progress...\n")
            suspiciousIPTraffic = True


    if (suspiciousIPTraffic == False):
        print("No suspicious DDoS traffic found")


#
# Create IP dictionary containing the number of packets from each IP address
#
def createIPDict(pcapFileName):
    
    # open .pcap file with scapy
    cap = rdpcap("packet_captures/"+pcapFileName)

    # create new IP dict
    ipAddressDict = {}  # Dictionary to count packets per source IP address

    # fill IP dict
    for packet in cap:
        if "IP" in packet:

            # Count the number of packets from each source IP address
            src_ip = packet["IP"].src
            ipAddressDict[src_ip] = ipAddressDict.get(src_ip, 0) + 1


    # Open a file in write mode
    with open("output.txt", "w") as file:
        # Iterate through the keys of ipAddressDict
        for address in ipAddressDict.keys():
            # Write each address followed by a newline to the file
            file.write(address + "\n")
    return ipAddressDict


#
# Search through each IP address in dictionary, looking for matches against given and user-defined malicious IP addresses
#
def detectMaliciousIPAddress(ipAddressDict):

    # setup for malicious IP detection
    standardMalFile = open("standard_ip_banlist.txt","r")
    lines = standardMalFile.readlines()
    maliciousIPs = []
    flag = False

    # load standard list of malicious IPs
    for line in lines:
        maliciousIPs.append(line[:-1])
    standardMalFile.close()

    userDefinedMalFile = open("user_defined_ip_banlist.txt","r")
    lines = userDefinedMalFile.readlines()

    # load user-defined list of malicious IPs
    for line in lines:
        maliciousIPs.append(line[:-1])
    userDefinedMalFile.close()

    # check if any source IPs from capture appear on malicious list
    for ipAddress in ipAddressDict.keys():
        for mal in maliciousIPs:
            if ipAddress == mal:
                print("Malicious IP found")
                flag = True

    # inform user of result of search
    if flag == False:
        print("No IP addresses were found to be malicious")


#
# Grab values from control text file for context analysis
#
def getControlValues():

    controlFile = open("control_file.txt","r")

    lines = controlFile.readlines()
    totalPackets = 0
    totalCaptureTime = 0.0
    avgPacketsPerMin = 0

    lineCount = -1
    for line in lines:
        lineCount = lineCount + 1
        if lineCount == 0:
            avgPacketsPerMin = round(float(line[21:]),2)
        if lineCount == 1:
            totalPackets = int(line[24:])
        if lineCount == 2:
            totalCaptureTime = round(float(line[20:]),2)

    controlFile.close()

    return avgPacketsPerMin,totalPackets,totalCaptureTime


#
# Grab values from context text file for context analysis
#
def getContextValues(contextFileName):

    contextFile = open("control_file.txt","r")

    lines = contextFile.readlines()
    numOfPackets = 0
    captureTime = 0.0
    avgPacketsPerMin = 0

    lineCount = -1
    for line in lines:
        lineCount = lineCount + 1
        if lineCount == 0:
            avgPacketsPerMin = round(float(line[21:]),2)
        if lineCount == 1:
            numOfPackets = int(line[24:])
        if lineCount == 2:
            captureTime = round(float(line[20:]),2)

    contextFile.close()

    return avgPacketsPerMin,numOfPackets,captureTime


#
# Update control file with information from the context file for the latest capture
#
def updateControlFile(captureCount,captureTime):
    
    controlAvgPackets,controlTotalPackets,controlTotalTime = getControlValues()

    controlFile = open("control_file.txt","w")

    newTotalCaptureTime = round(controlTotalTime + captureTime,2)
    newTotalPackets = controlTotalPackets + captureCount
    newAvgPackets = round((newTotalPackets / newTotalCaptureTime) * 60,2)

    controlFile.write("avg_packets_per_min: "+str(newAvgPackets)+"\ntotal_packets_captured: "+str(newTotalPackets)+"\ntotal_capture_time: "+str(newTotalCaptureTime))
    controlFile.close()



#
# Create context file to hold info about latest packet capture
#   
def createContextFile(network_traffic_filename,captureName):
    contextFileName = "network_context_file_" + captureName + ".txt"

    context_file = open("network_contexts/"+contextFileName,"w")


    pcapFileName = network_traffic_filename

    control_file = open("control_file.txt","r")

    lines = control_file.readlines()

    lineCount = -1
    for line in enumerate(lines):
        lineCount += 1
        if lineCount == 0:
            avgPacketsPerMin = line[21:]

    control_file.close()

    # get packet count
    print('Opening {}...'.format(pcapFileName))

    cap = rdpcap("packet_captures/"+pcapFileName)

    first_time = 0
    last_time = 0
    count = 0

    TCP_count = 0
    UDP_count = 0

    for packet in cap:
        count+= 1
        if count == 1:
            first_time = packet.time
        last_time = packet.time

        if "TCP" in packet:
            TCP_count += 1

        if "UDP" in packet:
            UDP_count += 1

    # Calculate the time difference
    time_difference = last_time - first_time


    try:
        packetsPerMinute = round((count / time_difference) * 60,2)
    except:
        packetsPerMinute = 0.00

    
    # Close the capture file
    context_file.write("This is a context file. It contains information about the network traffic capture.\n\n" + 
                       "number_of_packets_captured: "+ str(count)+"\n"+"capture_time: " + str(time_difference) +
                       "\n"+"average_packets_captured_per_minute: " + str(packetsPerMinute)+"\nnumber_of_TCP_packets: "+str(TCP_count)+
                       "\n"+"number_of_UDP_packets: "+str(UDP_count))
    context_file.close()

    updateControlFile(count,time_difference)

    return contextFileName


#
# Analysis of packet capture
#        
def analysisPCAPFile(pcapFileName,contextFileName):

    # create source IP list from capture
    ipAddressDict = createIPDict(pcapFileName)

    # add ip Dict to context file
    contextFile = open("network_contexts/"+contextFileName,"a")

    contextFile.write("\n")
    for key in ipAddressDict.keys():
        contextFile.write(key+"\n"+str(ipAddressDict.get(key))+"\n")
    contextFile.close()
    

    # various analysis of .pcap file
    detectDDOS(ipAddressDict,contextFileName)
    detectMaliciousIPAddress(ipAddressDict)


#
# Create name for related files based on time the packet capture occurred
#
def createCaptureName():

# Get the current date and time
    now = datetime.datetime.now()

    # Create a datetime object representing the current date and time
    year = now.strftime("%Y")
    month = now.strftime("%m")
    day = now.strftime("%d")
    time = now.strftime("%H:%M:%S")
    
    str_output = re.sub(":", "-", str(time))
    captureName = str(year) + "-" + str(month) + "-" + str(day) + "-" + str(str_output)

    return captureName


#
# Packet Capture With Minimum Packets
#
def captureNetworkTrafficWithMin(interface):

    #configurations
    timeout_time = int(sys.argv[2])
    min_packets = int(sys.argv[3])

    captureName = createCaptureName()

    # Create a LiveCapture object to capture packets from the specified interface
    capture = pyshark.LiveCapture(interface=interface,output_file="packet_captures/network_traffic_file_"+captureName+".pcap")

    f = open("packet_captures/captureName"+".pcap",'wb')

    # Start capturing packets for a specified duration (in seconds)
    #capture.sniff(timeout=timeout_time)

    #condition = True
    packetCount = 0

    for packet in capture.sniff_continuously(packet_count=min_packets):  # Adjust packet_count based on your needs
    # Process the packet here
        packetCount += 1
        
        # Check if the number of packets captured reaches the desired floor
        if packetCount >= min_packets:
            break
                
    
    f.close()

    return captureName
                    

#
# Packet Capture Without Minimum Packets
#
def captureNetworkTrafficWithoutMin(interface):

    #configurations
    timeout_time = int(sys.argv[2])

    captureName = createCaptureName()

    # Create a LiveCapture object to capture packets from the specified interface
    capture = pyshark.LiveCapture(interface=interface,output_file="packet_captures/network_traffic_file_" + captureName+".pcap")

    f = open("packet_captures/network_traffic_file_" + captureName+".pcap",'wb')

    # Start capturing packets for a specified duration (in seconds)
    capture.sniff(timeout=timeout_time)

    f.close()

    return captureName
                    
                   
def main():
    
    # Specify the network interface to capture packets from
    interface = 'wifi'

    captureWithMin = False
    captureWithoutMin = True


    #GUI AFFECTS OPTION VARIABLE


    if sys.argv[1] == "True":
        captureName = captureNetworkTrafficWithMin(interface)
    else:
        captureName = captureNetworkTrafficWithoutMin(interface)

    
    
    pcapFileName = "network_traffic_file_" + captureName + ".pcap"
    
    contextFileName = createContextFile(pcapFileName,captureName)

    print(contextFileName)
    
    analysisPCAPFile(pcapFileName,contextFileName)

    # Call the trace_network_traffic function to start capturing and analyzing network traffic
    #captureNetworkTrafficWithMin(interface)

# Execute the main function
if __name__ == '__main__':
    main()
